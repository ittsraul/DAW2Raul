import { Component } from '@angular/core';

@Component({
  selector: 'app-cortoplazo',
  templateUrl: './cortoplazo.component.html',
  styleUrls: ['./cortoplazo.component.css']
})
export class CortoplazoComponent {

}
