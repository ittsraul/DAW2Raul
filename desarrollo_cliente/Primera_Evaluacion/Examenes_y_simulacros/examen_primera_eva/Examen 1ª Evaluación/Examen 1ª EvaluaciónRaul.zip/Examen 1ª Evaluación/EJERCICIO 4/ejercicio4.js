let tabla = document.getElementsByClassName("table-wrapper")[0];

//Create the funtion for make the dinamic content of  breaking bad
function dinamicDiv() {
    let p = document.createElement("p");
    tabla.appendChild(p);
    let imagen = document.createElement("img");
    tabla.appendChild(imagen);
    imagen.style.width = "300px";
    imagen.style.height = "400px";
    let antes = document.createElement("button");
    tabla.appendChild(antes);
    let despues = document.createElement("button");
    tabla.appendChild(despues);
    antes.innerHTML = "anterior";
    despues.innerHTML = "despues";
}

//Call the dinamic function
dinamicDiv();

 //Peticion a la api publica
/* function breakingBad() {
    fetch("https://breakingbadapi.com/documentation").then(response => {
        if (response.ok) {
            return response.json();
        } else {
            console.log("An error was ocurred");
        }
    }).then(jsonResponse => {
            console.log(jsonResponse);
        },
    }); 
} */

// breakingBad();
