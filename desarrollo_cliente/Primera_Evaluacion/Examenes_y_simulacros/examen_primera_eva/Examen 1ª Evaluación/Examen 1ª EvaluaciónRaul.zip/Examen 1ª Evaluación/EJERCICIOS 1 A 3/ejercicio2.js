let SegundoNivelAs = document.getElementsByTagName("h2")[0];

let body = document.body;

body.addEventListener("mousemove", (e)=>{
    
    SegundoNivelAs.style.height =
    SegundoNivelAs.style.color ="lightGrey";
    SegundoNivelAs.style.color ="beige";
    SegundoNivelAs.style.color ="blueViolet";
    SegundoNivelAs.style.color ="coral"
    SegundoNivelAs.style.color ="powerBlue";
})


    let y = e.y + document.body.scrollTop;

    SegundoNivelAs.style.height = y + 'px';
    if (y >= 0 && y<= 50) {
        SegundoNivelAs.style.color ="darkGoldenRod";
    } else if{
        y 
    }
