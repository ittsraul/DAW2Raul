<?php
    // modelo -> proporciona los datos necesarios a la aplicación
    $diccionario = array(
                        'page_title'=>'MVC en PHP',
                        'keywords'=>'poo, mvc, php, arquitectura de software',
                        'description'=>'ponemos en práctica el MVC en PHP',
                        'content'=>'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ut lorem eu justo blandit laoreet. Curabitur sem nisl, eleifend fermentum sem nec, condimentum sodales mauris. Duis facilisis hendrerit fermentum. Suspendisse venenatis ipsum nisl, nec scelerisque velit faucibus ac. Aliquam erat volutpat. Donec quis enim non risus gravida semper eget eget tellus. Sed fermentum cursus consectetur.'
    );
?>

