<?php
    require('model.php'); //pide al modelo los datos necesarios
    require('view.php') //envia a la vista los datos para su visualización
?>

