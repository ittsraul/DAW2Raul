<?php
//Controlador que da paso a los archivos
require_once('model.php');
require_once('vista.php');
$accion=$_GET["action"];
$n=$_GET["n"];
switch($accion){
    case "saying":
        /* for($i=0;$i < count($sayings);$i++){
            if($n==$i){
                echo $sayings[$i];
            }/* else{
                echo "tienes un error";
            } }*/
        echo "\n" . $sayings[$n];
        break;
    case "hello":
        echo "hola" . time();
        break;
    case "bye":
    echo "Muchas gracias tio" . time();
    break;
    default:
    echo "hay un error cara pinga";
    break;
}
/* Numero aleatorio:    $posicion=rand(0,count($sayings) -1);
echo $sayings[$posicion]; */
?>